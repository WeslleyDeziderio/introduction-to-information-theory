#include "../libs/encoder.hpp"

void Encoder::printHello() {
    std::cout << "Hello world!" << std::endl;
}