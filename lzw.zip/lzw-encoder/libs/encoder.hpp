#ifndef ENCODER_HPP
#define ENCODER_HPP

#include <iostream>

class Encoder {
public:
    void printHello();

};

#endif